export { default as HtmlDialog } from './components/HtmlDialog.vue';
export { default as FullNativeDialog } from './components/FullNativeDialog.vue';